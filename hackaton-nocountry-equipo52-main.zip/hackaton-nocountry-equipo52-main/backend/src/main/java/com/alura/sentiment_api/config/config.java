package com.alura.sentiment_api.config;

public class config {
    
}
