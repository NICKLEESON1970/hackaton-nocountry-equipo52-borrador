package com.alura.sentiment_api.client;

public class client {
    
}
