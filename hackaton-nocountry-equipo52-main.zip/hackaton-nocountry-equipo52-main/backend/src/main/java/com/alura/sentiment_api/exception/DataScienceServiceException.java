package com.alura.sentiment_api.exception;

public class DataScienceServiceException extends RuntimeException {
    public DataScienceServiceException(String message) {
        super(message);
    }
}
